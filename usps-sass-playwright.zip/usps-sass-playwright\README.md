# USPS SASS Playwright

End-to-end test automation for the USPS SASS development application. The framework uses TypeScript, validated environment configuration, reusable page objects, isolated authentication state, and CI-ready diagnostics.

## Prerequisites

- Node.js 20 or newer
- Google Chrome (enterprise-managed install)
- An authorized USPS non-production account
- Network access to `sass-services-dev.usps.gov` and `login-dev.usps.gov`

## Local setup

The project `.npmrc` uses the approved USPS Artifactory npm proxy. It contains no credentials and keeps TLS validation enabled. Verify access before installing:

```powershell
[Environment]::SetEnvironmentVariable('NODE_OPTIONS', '--use-system-ca', 'User')
npm ping
```

Node 24 needs `--use-system-ca` to trust the USPS certificate authority already installed in the Windows certificate store. Restart VS Code after setting the user environment variable so new terminals inherit it. Do not set `strict-ssl=false`.

If authentication becomes required, use the registry's approved login mechanism. Do not place passwords or access tokens in the project `.npmrc`.

After `npm ping` succeeds:

```powershell
Copy-Item .env.example .env
npm install
```

Local tests use the enterprise-managed Google Chrome installation through Playwright's `chrome` channel. No Playwright browser download is required.

Commit the generated `package-lock.json` before enabling CI so builds can use deterministic `npm ci` installs.

Open the ignored `.env` file locally and populate:

```dotenv
SASS_USERNAME=your-username
SASS_PASSWORD=your-password
```

Never commit `.env` or `.auth`. Both paths are ignored by Git.

## Running tests

```powershell
# Establish and inspect authentication in a visible browser
npm run auth

# Run the complete Chromium suite
npm test

# Run release-gating smoke coverage
npm run test:smoke

# Validate TypeScript and lint rules
npm run check
```

The `auth.setup` project signs in once per test run and writes browser state to `.auth/user.json`. Dependent tests reuse that state instead of repeating the login flow.

If the identity provider requires MFA or a new-device challenge, run `npm run auth` and complete the challenge in the visible browser before the 120-second callback timeout. CI service accounts must use an organization-approved non-interactive authentication policy; do not bypass MFA in test code.

## Structure

```text
src/
  config/       Typed environment parsing and validation
  fixtures/     Shared Playwright dependency injection
  pages/        Page objects and application behavior
tests/
  auth.setup.ts Authentication state creation
  smoke/        Small release-gating checks
```

Tests should express business behavior through fixtures and page objects. Keep selectors inside the owning page object, prefer accessible role/name locators, and add assertions at stable application boundaries rather than against implementation details.

## CI secrets

The GitHub Actions workflow expects these repository or environment secrets:

- `SASS_USERNAME`
- `SASS_PASSWORD`

Test failures retain the HTML report, screenshots, traces, and JUnit XML under the workflow artifact. Configure a protected GitHub environment and an appropriately networked runner if the development application is not reachable from GitHub-hosted runners.
