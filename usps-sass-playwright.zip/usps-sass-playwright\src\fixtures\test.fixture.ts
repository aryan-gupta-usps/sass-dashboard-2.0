import { test as base, expect } from '@playwright/test';

import { environment } from '../config/environment.js';
import { DashboardPage } from '../pages/dashboard.page.js';

interface ApplicationFixtures {
  dashboardPage: DashboardPage;
}

export const test = base.extend<ApplicationFixtures>({
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page, environment.baseUrl));
  },
});

export { expect };
