import path from 'node:path';

import { config as loadEnvironment } from 'dotenv';
import { z } from 'zod';

loadEnvironment({ path: path.resolve(process.cwd(), '.env'), quiet: true });

const booleanValue = z
  .enum(['true', 'false'])
  .default('false')
  .transform((value) => value === 'true');

const environmentSchema = z.object({
  SASS_BASE_URL: z.url().default('https://sass-services-dev.usps.gov'),
  SASS_USERNAME: z.string().optional(),
  SASS_PASSWORD: z.string().optional(),
  AUTH_STORAGE_PATH: z.string().min(1).default('.auth/user.json'),
  IGNORE_HTTPS_ERRORS: booleanValue,
});

const parsedEnvironment = environmentSchema.safeParse(process.env);

if (!parsedEnvironment.success) {
  throw new Error(`Invalid environment configuration:\n${z.prettifyError(parsedEnvironment.error)}`);
}

const values = parsedEnvironment.data;

export const environment = Object.freeze({
  baseUrl: values.SASS_BASE_URL.replace(/\/$/, ''),
  authStoragePath: path.resolve(process.cwd(), values.AUTH_STORAGE_PATH),
  ignoreHttpsErrors: values.IGNORE_HTTPS_ERRORS,
});

export interface Credentials {
  username: string;
  password: string;
}

export function requireCredentials(): Credentials {
  const credentials = z
    .object({
      username: z.string().trim().min(1, 'SASS_USERNAME is required'),
      password: z.string().min(1, 'SASS_PASSWORD is required'),
    })
    .safeParse({
      username: values.SASS_USERNAME,
      password: values.SASS_PASSWORD,
    });

  if (!credentials.success) {
    throw new Error(
      `Missing login credentials. Populate the local .env file:\n${z.prettifyError(credentials.error)}`,
    );
  }

  return credentials.data;
}
