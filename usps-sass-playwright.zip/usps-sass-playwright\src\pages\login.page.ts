import { expect, type Page } from '@playwright/test';

import type { Credentials } from '../config/environment.js';

export class LoginPage {
  public constructor(
    private readonly page: Page,
    private readonly applicationBaseUrl: string,
  ) {}

  public async open(): Promise<void> {
    await this.page.goto(this.applicationBaseUrl);
    await expect(this.page.getByRole('textbox', { name: 'Username' })).toBeVisible();
  }

  public async signIn(credentials: Credentials): Promise<void> {
    await this.page.getByRole('textbox', { name: 'Username' }).fill(credentials.username);
    await this.page.getByRole('button', { name: 'Next' }).click();

    const password = this.page.getByLabel('Password');
    await expect(password).toBeVisible();
    await password.fill(credentials.password);
    await this.page.getByRole('button', { name: /^(Verify|Sign In)$/i }).click();

    const applicationOrigin = new URL(this.applicationBaseUrl).origin;
    await this.page.waitForURL(
      (url) => url.origin === applicationOrigin && !url.pathname.startsWith('/login/callback'),
      { timeout: 120_000 },
    );
  }
}
