import { defineConfig, devices } from '@playwright/test';

import { environment } from './src/config/environment.js';

const isContinuousIntegration = Boolean(process.env.CI);

export default defineConfig({
  testDir: './tests',
  outputDir: 'test-results',
  fullyParallel: true,
  forbidOnly: isContinuousIntegration,
  retries: isContinuousIntegration ? 2 : 0,
  ...(isContinuousIntegration ? { workers: 1 } : {}),
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: isContinuousIntegration
    ? [
        ['line'],
        ['html', { open: 'never' }],
        ['junit', { outputFile: 'test-results/junit.xml' }],
      ]
    : [
        ['list'],
        ['html', { open: 'never' }],
      ],
  use: {
    baseURL: environment.baseUrl,
    channel: 'chrome',
    ignoreHTTPSErrors: environment.ignoreHttpsErrors,
    actionTimeout: 15_000,
    navigationTimeout: 30_000,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'off',
  },
  projects: [
    {
      name: 'auth.setup',
      testMatch: /auth\.setup\.ts/,
      use: {
        screenshot: 'off',
        trace: 'off',
      },
    },
    {
      name: 'chromium',
      dependencies: ['auth.setup'],
      testIgnore: /auth\.setup\.ts/,
      use: {
        ...devices['Desktop Chrome'],
        storageState: environment.authStoragePath,
      },
    },
  ],
});