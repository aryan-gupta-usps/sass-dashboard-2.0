import { test } from '../../src/fixtures/test.fixture.js';

test('authenticated application shell loads @smoke', async ({ dashboardPage }) => {
  await dashboardPage.open();
  await dashboardPage.expectLoaded();
});