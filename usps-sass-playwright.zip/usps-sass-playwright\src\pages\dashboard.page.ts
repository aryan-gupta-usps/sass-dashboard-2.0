import { expect, type Page } from '@playwright/test';

export class DashboardPage {
  public constructor(
    private readonly page: Page,
    private readonly applicationBaseUrl: string,
  ) {}

  public async open(): Promise<void> {
    await this.page.goto('/');
  }

  public async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(new RegExp(`^${escapeRegex(this.applicationBaseUrl)}(?:/|$)`));
    await expect(this.page.locator('app-root')).toBeVisible();
    await expect(this.page.getByText('Authentication Error:', { exact: false })).toHaveCount(0);
  }
}

function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
