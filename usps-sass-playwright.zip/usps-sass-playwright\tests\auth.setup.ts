import { test as setup } from '@playwright/test';

import { environment, requireCredentials } from '../src/config/environment.js';
import { DashboardPage } from '../src/pages/dashboard.page.js';
import { LoginPage } from '../src/pages/login.page.js';

setup('authenticate with USPS Enterprise Identity Provider', async ({ page }) => {
  setup.setTimeout(180_000);

  const loginPage = new LoginPage(page, environment.baseUrl);
  await loginPage.open();
  await loginPage.signIn(requireCredentials());

  const dashboardPage = new DashboardPage(page, environment.baseUrl);
  await dashboardPage.expectLoaded();
  await page.context().storageState({ path: environment.authStoragePath });
});
